// HashGen - Interactive JavaScript

document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
});

function initializeApp() {
    setupTextarea();
    setupPlatformSelector();
    setupExamples();
    setupKeyboardShortcuts();
}

// Textarea character counter
function setupTextarea() {
    const textarea = document.getElementById('caption');
    const charCount = document.getElementById('charCount');

    textarea.addEventListener('input', function() {
        charCount.textContent = this.value.length;
        updateCharCountColor();
    });

    function updateCharCountColor() {
        const length = textarea.value.length;
        charCount.className = length > 500 ? 'char-count warning' : 'char-count';
    }
}

// Platform selector
function setupPlatformSelector() {
    const options = document.querySelectorAll('.platform-option');

    options.forEach(option => {
        option.addEventListener('click', function() {
            options.forEach(opt => opt.classList.remove('active'));
            this.classList.add('active');
        });
    });
}

// Example tags
function setupExamples() {
    const exampleTags = document.querySelectorAll('.example-tag');
    const textarea = document.getElementById('caption');
    const charCount = document.getElementById('charCount');

    const examples = {
        '🌅 Sunset hike': "Just finished the most breathtaking sunset hike up the mountains today. The views were absolutely incredible and the fresh air was so refreshing.",
        '☕ Morning coffee': "Starting my morning with the perfect cup of coffee. There's nothing better than a quiet morning with a good book and great coffee.",
        '💪 Post-workout': "Crushed my workout today at the gym! Feeling stronger every day. Consistency is key when it comes to fitness goals.",
        '✈️ Exploring Tokyo': "Lost in the beautiful streets of Tokyo today. The food, the culture, the people — everything is absolutely amazing here.",
        '🎨 Digital art': "Finally finished my new digital art illustration. Spent hours on the details and I'm so proud of how it turned out."
    };

    exampleTags.forEach(tag => {
        tag.addEventListener('click', function() {
            const key = this.textContent.trim();
            if (examples[key]) {
                textarea.value = examples[key];
                charCount.textContent = textarea.value.length;
                textarea.focus();

                // Add click animation
                this.style.transform = 'scale(0.95)';
                setTimeout(() => {
                    this.style.transform = '';
                }, 150);
            }
        });
    });
}

// Keyboard shortcuts
function setupKeyboardShortcuts() {
    const textarea = document.getElementById('caption');

    textarea.addEventListener('keydown', function(e) {
        if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
            e.preventDefault();
            generateHashtags();
        }
    });
}

// Generate hashtags
async function generateHashtags() {
    const textarea = document.getElementById('caption');
    const caption = textarea.value.trim();
    const errorMessage = document.getElementById('errorMsg');
    const generateBtn = document.getElementById('generateBtn');
    const btnText = generateBtn.querySelector('.btn-text');
    const loadingState = document.getElementById('loadingState');
    const resultsSection = document.getElementById('resultsSection');

    // Hide error
    errorMessage.style.display = 'none';

    // Validation
    if (!caption) {
        showError('Please enter a caption first.');
        return;
    }

    if (caption.length < 5) {
        showError('Please enter a longer caption (at least 5 characters).');
        return;
    }

    // Get selected platform
    const activePlatform = document.querySelector('.platform-option.active');
    const platform = activePlatform ? activePlatform.dataset.platform : 'instagram';

    // Update UI for loading
    generateBtn.disabled = true;
    generateBtn.classList.add('loading');
    btnText.innerHTML = '<div class="spinner"></div> Generating...';
    loadingState.style.display = 'block';
    resultsSection.classList.remove('visible');

    try {
        const response = await fetch('/generate', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ caption, platform })
        });

        const data = await response.json();

        if (!response.ok) {
            throw new Error(data.error || 'Something went wrong');
        }

        // Success - render results
        renderResults(data);

    } catch (error) {
        showError(error.message || 'Failed to generate hashtags. Please try again.');
    } finally {
        // Reset UI
        generateBtn.disabled = false;
        generateBtn.classList.remove('loading');
        btnText.innerHTML = '✨ Generate Hashtags';
        loadingState.style.display = 'none';
    }
}

function showError(message) {
    const errorMessage = document.getElementById('errorMsg');
    errorMessage.textContent = message;
    errorMessage.style.display = 'block';

    // Scroll to error
    errorMessage.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

function renderResults(data) {
    const resultsSection = document.getElementById('resultsSection');
    const resultsCount = document.getElementById('resultsCount');
    const allTagsPreview = document.getElementById('allTagsPreview');

    // Update count
    resultsCount.textContent = `${data.count} hashtags`;

    // Update preview
    allTagsPreview.textContent = data.all_text;

    // Render tag groups
    renderTagGroup('nicheGroup', data.categorized.niche, 'niche');
    renderTagGroup('generalGroup', data.categorized.general, 'general');
    renderTagGroup('powerGroup', data.categorized.power, 'power');

    // Show results with animation
    resultsSection.classList.add('visible');

    // Scroll to results
    setTimeout(() => {
        resultsSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 100);
}

function renderTagGroup(groupId, tags, type) {
    const group = document.getElementById(groupId);
    const tagsGrid = group.querySelector('.tags-grid');

    if (!tags || tags.length === 0) {
        group.style.display = 'none';
        return;
    }

    group.style.display = 'block';
    tagsGrid.innerHTML = '';

    // Stagger animation for tags
    tags.forEach((tag, index) => {
        const tagElement = document.createElement('div');
        tagElement.className = 'tag';
        tagElement.textContent = tag;
        tagElement.style.animationDelay = `${index * 0.05}s`;
        tagElement.addEventListener('click', () => copyTag(tagElement, tag));
        tagsGrid.appendChild(tagElement);
    });
}

function copyTag(element, tag) {
    navigator.clipboard.writeText(tag).then(() => {
        // Visual feedback
        element.classList.add('copied');
        element.textContent = '✓ Copied!';

        // Reset after animation
        setTimeout(() => {
            element.classList.remove('copied');
            element.textContent = tag;
        }, 1500);

        // Add ripple effect
        createRipple(element);
    }).catch(() => {
        // Fallback for older browsers
        const textArea = document.createElement('textarea');
        textArea.value = tag;
        document.body.appendChild(textArea);
        textArea.select();
        document.execCommand('copy');
        document.body.removeChild(textArea);

        element.classList.add('copied');
        element.textContent = '✓ Copied!';
        setTimeout(() => {
            element.classList.remove('copied');
            element.textContent = tag;
        }, 1500);
    });
}

function copyAll() {
    const allTagsPreview = document.getElementById('allTagsPreview');
    const copyBtn = document.getElementById('copyAllBtn');

    const text = allTagsPreview.textContent;
    navigator.clipboard.writeText(text).then(() => {
        copyBtn.classList.add('copied');
        copyBtn.textContent = '✓ Copied!';

        setTimeout(() => {
            copyBtn.classList.remove('copied');
            copyBtn.textContent = 'Copy All';
        }, 2000);

        createRipple(copyBtn);
    });
}

function createRipple(element) {
    const ripple = document.createElement('div');
    const rect = element.getBoundingClientRect();
    const size = Math.max(rect.width, rect.height);
    const x = event.clientX - rect.left - size / 2;
    const y = event.clientY - rect.top - size / 2;

    ripple.style.width = ripple.style.height = size + 'px';
    ripple.style.left = x + 'px';
    ripple.style.top = y + 'px';
    ripple.className = 'ripple';

    element.appendChild(ripple);

    setTimeout(() => {
        ripple.remove();
    }, 600);
}

// Add ripple CSS dynamically
const rippleStyle = document.createElement('style');
rippleStyle.textContent = `
    .ripple {
        position: absolute;
        border-radius: 50%;
        background: rgba(255, 255, 255, 0.3);
        transform: scale(0);
        animation: ripple 0.6s linear;
        pointer-events: none;
    }

    @keyframes ripple {
        to {
            transform: scale(4);
            opacity: 0;
        }
    }
`;
document.head.appendChild(rippleStyle);

// Make functions global for onclick handlers
window.generateHashtags = generateHashtags;
window.copyAll = copyAll;