import os
import re
import numpy as np
import pandas as pd
import faiss
from flask import Flask, request, jsonify, render_template

app = Flask(__name__)

def clean_text(text):
    """Lowercase and remove non-alphabetic characters."""
    if isinstance(text, str):
        text = re.sub(r'[^A-Za-z\s\?\'\-]', '', text)
        return text.lower().strip()
    return ''

def load_medical_data():
    base_dir  = os.path.dirname(os.path.abspath(__file__))
    data_path = os.path.join(base_dir, "data")
    csv_file  = os.path.join(data_path, "medical_center_qna.csv")

    if not os.path.exists(csv_file):
    
        csv_file = os.path.join(base_dir, "medical_center_qna.csv")
        if not os.path.exists(csv_file):
            print("[ERROR] medical_center_qna.csv not found. "
                  "Place it in the 'data' folder or next to app.py")
            exit(1)

    df = pd.read_csv(
        csv_file,
        quotechar='"',
        on_bad_lines='skip',
        engine='python'
    )

    required_cols = {"question", "answer"}
    if not required_cols.issubset(df.columns):
        raise ValueError("CSV must contain 'question' and 'answer' columns")


    df.dropna(subset=["question", "answer"], inplace=True)
    df = df[df["question"].str.strip() != ""]
    df = df[df["answer"].str.strip() != ""]
    df.reset_index(drop=True, inplace=True)


    if "category" not in df.columns:
        df["category"] = "General"


    df["clean_question"] = df["question"].apply(clean_text)

    print(f"[INFO] Loaded {len(df)} medical QnA pairs successfully")
    return df

def build_embeddings(df, model):
    print("[INFO] Creating sentence embeddings with MiniLM...")
    embeddings = model.encode(
        df["clean_question"].tolist(),
        convert_to_numpy=True,
        show_progress_bar=True
    )
    return embeddings.astype(np.float32)

def build_faiss_index(embeddings):
    dim   = embeddings.shape[1]
    index = faiss.IndexFlatL2(dim) 
    index.add(embeddings)
    print(f"[INFO] FAISS index built with {index.ntotal} vectors (dim={dim})")
    return index

def retrieve_answers(query, model, index, df, k=3):
    """
    Embed the query using MiniLM, search the FAISS index,
    and return the top-k most similar QnA pairs.
    """
    query_vec          = model.encode([clean_text(query)]).astype(np.float32)
    distances, indices = index.search(query_vec, k)

    results = []
    for rank, (idx, dist) in enumerate(zip(indices[0], distances[0])):
        if idx == -1:
            continue
        row = df.iloc[idx]
    
        confidence = max(0, 100 - float(dist) * 20)
        results.append({
            "rank":       rank + 1,
            "question":   row["question"],
            "answer":     row["answer"],
            "category":   row.get("category", "General"),
            "distance":   float(dist),
            "confidence": round(confidence, 1)
        })

    return results

print("[START] Loading Hugging Face MiniLM model...")
from sentence_transformers import SentenceTransformer
model = SentenceTransformer("paraphrase-MiniLM-L6-v2")

print("[START] Loading medical center dataset...")
medical_df = load_medical_data()

print("[START] Building sentence embeddings...")
embeddings = build_embeddings(medical_df, model)

print("[START] Building FAISS index...")
faiss_index = build_faiss_index(embeddings)

print("[READY] Medical Center QnA Bot is running!")

@app.route("/")
def home():
    return render_template("index.html")


@app.route("/ask", methods=["POST"])
def ask():
    data  = request.get_json()
    query = data.get("query", "").strip()

    if not query:
        return jsonify({"error": "Empty query"}), 400

    results = retrieve_answers(query, model, faiss_index, medical_df)

    return jsonify({
        "query":   query,
        "results": results
    })


if __name__ == "__main__":
    app.run(debug=True, port=5000)
