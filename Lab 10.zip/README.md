# HashGen — AI Hashtag Generator 🔥

A Flask + NLP web app that generates smart, relevant hashtags from your Instagram/social media caption.

## Features
- **NLP-powered** keyword extraction (stopword removal, bigram detection)
- **Niche expansion** — maps your keywords to 30+ topic clusters (food, fitness, travel, fashion, tech, art, etc.)
- **Categorized output** — Niche tags, General tags, Power tags
- **One-click copy** — copy individual tags or all at once
- **Platform selector** — Instagram, Twitter/X, TikTok, LinkedIn
- **Zero external dependencies** — pure Python NLP, no API keys needed

## Setup & Run

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Run the app
python app.py

# 3. Open browser
# Go to http://127.0.0.1:5000
```

## Project Structure
```
hashtag-generator/
├── app.py              # Flask backend + NLP engine
├── requirements.txt    # Dependencies (just Flask)
├── templates/
│   └── index.html      # Frontend UI
└── README.md
```

## How It Works

1. **Clean text** — lowercases, strips punctuation
2. **Extract keywords** — removes 150+ stopwords, filters short/numeric tokens
3. **Niche mapping** — matches keywords to curated topic clusters (e.g. "coffee" → coffeelover, coffeeaddict, morningcoffee...)
4. **Bigrams** — combines adjacent meaningful words (e.g. "morning coffee" → morningcoffee)
5. **Power tags** — appends high-reach universal tags
6. **Rank & return** — sorts by niche score + length, returns top 30

## Extend It

- Add more niche categories in `NICHE_MAP` inside `app.py`
- Connect to a real NLP library like `spaCy` or `NLTK` for even better keyword extraction
- Add a database to save favorite hashtag sets
