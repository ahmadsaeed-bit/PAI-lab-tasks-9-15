from flask import Flask, render_template, request, jsonify
import re
import string
from collections import Counter
import spacy

app = Flask(__name__)

# Load spaCy model
try:
    nlp = spacy.load('en_core_web_sm')
except OSError:
    print("spaCy model 'en_core_web_sm' not found. Please run: python -m spacy download en_core_web_sm")
    nlp = None

# --------------- NLP Core ---------------

STOPWORDS = {
    'i','me','my','myself','we','our','ours','ourselves','you','your','yours',
    'yourself','yourselves','he','him','his','himself','she','her','hers',
    'herself','it','its','itself','they','them','their','theirs','themselves',
    'what','which','who','whom','this','that','these','those','am','is','are',
    'was','were','be','been','being','have','has','had','having','do','does',
    'did','doing','a','an','the','and','but','if','or','because','as','until',
    'while','of','at','by','for','with','about','against','between','into',
    'through','during','before','after','above','below','to','from','up','down',
    'in','out','on','off','over','under','again','further','then','once','here',
    'there','when','where','why','how','all','both','each','few','more','most',
    'other','some','such','no','nor','not','only','own','same','so','than','too',
    'very','s','t','can','will','just','don','should','now','d','ll','m','o',
    're','ve','y','ain','aren','couldn','didn','doesn','hadn','hasn','haven',
    'isn','ma','mightn','mustn','needn','shan','shouldn','wasn','weren','won',
    'wouldn','i\'m','i\'ve','i\'ll','i\'d','let','us','also','even','get','got',
    'much','many','like','just','really','want','going','love','check','out',
    'new','today','day','time','way','make','made','good','great','look','see',
    'go','come','take','know','think','use','find','give','tell','feel','try',
    'ask','need','seem','leave','put','mean','keep','let','begin','show','hear',
    'play','run','move','live','believe','hold','bring','happen','write','sit',
    'stand','lose','pay','meet','include','continue','set','learn','change',
    'lead','understand','watch','follow','stop','create','speak','read','spend',
    'grow','open','walk','win','offer','remember','consider','appear','buy',
    'wait','serve','die','send','expect','build','stay','fall','cut','reach',
    'kill','remain','suggest','raise','pass','sell','require','report','decide',
    'pull','am','is','are','was','were'
}

# Niche keyword → related hashtag clusters
NICHE_MAP = {
    # Food
    'food':['foodie','foodphotography','instafood','foodlover','yummy','delicious','homecooking','foodblogger'],
    'eat':['foodie','foodphotography','instafood','foodlover','yummy'],
    'recipe':['recipe','homecooking','cookingathome','foodblogger','cheflife'],
    'cook':['cookingathome','homecooking','cheflife','foodblogger','kitchenlife'],
    'coffee':['coffeelover','coffeeaddict','morningcoffee','coffeetime','latteart','coffeeshop'],
    'cake':['cakedesign','cakelover','bakery','homebaking','pastrylife','sweettooth'],
    'pizza':['pizzalovers','pizzatime','italianfood','foodie'],
    # Fitness
    'gym':['gymlife','gymrat','fitness','workout','bodybuilding','gains','fitfam'],
    'workout':['workout','fitness','fitfam','training','gymlife','exercise','health'],
    'fitness':['fitness','fitfam','healthylifestyle','workout','bodygoals','fitnessjourney'],
    'yoga':['yoga','yogalife','yogapractice','mindfulness','wellness','namaste'],
    'run':['running','runnersworld','marathon','cardio','fitness','runninglife'],
    # Travel
    'travel':['travel','travelphotography','wanderlust','travelgram','explore','adventure'],
    'beach':['beach','beachlife','ocean','summer','paradise','beachvibes','sunset'],
    'mountain':['mountains','hiking','nature','adventure','outdoors','landscape','trekking'],
    'sunset':['sunset','sunsetphotography','goldenhour','sky','nature','beautiful'],
    'explore':['explore','adventure','travel','wanderlust','outdoors','discovery'],
    # Fashion
    'fashion':['fashion','style','ootd','outfitoftheday','fashionblogger','streetstyle'],
    'outfit':['ootd','outfitoftheday','fashion','style','fashionblogger','lookbook'],
    'style':['style','fashion','ootd','fashionista','streetstyle','trendy'],
    'dress':['dress','fashion','ootd','style','fashionista','womensfashion'],
    # Tech
    'tech':['technology','tech','innovation','coding','programming','developer','startup'],
    'code':['coding','programming','developer','softwaredeveloper','techlife','100daysofcode'],
    'ai':['artificialintelligence','machinelearning','ai','deeplearning','datascience','tech'],
    'app':['appdev','mobileapp','developer','coding','startup','tech'],
    # Art / Photography
    'photo':['photography','photographer','photooftheday','picoftheday','instaphoto','capture'],
    'art':['art','artwork','artist','digitalart','artofinstagram','creative','illustration'],
    'design':['design','graphicdesign','designer','creative','branding','uidesign'],
    'paint':['painting','art','artist','watercolor','artwork','creative','artofinstagram'],
    # Music
    'music':['music','musician','newmusic','instamusic','songwriting','producer'],
    'song':['music','newmusic','songwriting','musician','lyrics','instamusic'],
    'guitar':['guitar','guitarist','music','musician','guitarplayer','livemusic'],
    # Motivation
    'motivation':['motivation','inspirationalquotes','mindset','success','hustle','goals'],
    'success':['success','motivation','mindset','hustle','goalsetter','entrepreneurlife'],
    'hustle':['hustle','grind','entrepreneurlife','success','businessmindset','motivation'],
    'life':['lifestyle','lifequotes','lifeisbeautiful','gratitude','mindfulness'],
    # Nature
    'nature':['nature','naturephotography','wildlife','outdoors','earthpix','landscape'],
    'flower':['flowers','floral','nature','garden','botanical','flowerlovers','bloom'],
    'dog':['dogs','dogsofinstagram','puppy','doglovers','pets','doglife'],
    'cat':['cats','catsofinstagram','kitty','catlovers','meow','pets'],
    # Business
    'business':['business','entrepreneur','startup','businessmindset','marketing','leadership'],
    'brand':['branding','marketing','brand','business','creative','socialmedia'],
    'marketing':['marketing','digitalmarketing','socialmediamarketing','brand','contentmarketing'],
}

def clean_text(text):
    text = text.lower()
    text = re.sub(r'[^\w\s]', ' ', text)
    text = re.sub(r'\s+', ' ', text).strip()
    return text

def extract_keywords(caption):
    if nlp is None:
        # Fallback to basic extraction
        cleaned = clean_text(caption)
        words = cleaned.split()
        keywords = [w for w in words if w not in STOPWORDS and len(w) > 2 and not w.isdigit()]
        return keywords
    
    cleaned = clean_text(caption)
    doc = nlp(cleaned)
    keywords = [token.lemma_ for token in doc if token.is_alpha and not token.is_stop and len(token.lemma_) > 2]
    return keywords

def generate_hashtags(caption, platform='instagram'):
    keywords = extract_keywords(caption)
    hashtags = set()

    # Direct keyword hashtags
    for kw in keywords:
        hashtags.add(kw)

    # Niche expansion
    for kw in keywords:
        if kw in NICHE_MAP:
            for tag in NICHE_MAP[kw]:
                hashtags.add(tag)

    # Bigrams (two-word combos)
    words = [w for w in clean_text(caption).split() if w not in STOPWORDS and len(w) > 2]
    for i in range(len(words) - 1):
        bigram = words[i] + words[i+1]
        if len(bigram) > 5:
            hashtags.add(bigram)

    # Platform-specific power tags
    if platform == 'instagram':
        power_tags = ['instagood','instadaily','photooftheday','viral','trending','fyp','reels','explore','photography','insta']
        limit = 30
    elif platform == 'tiktok':
        power_tags = ['foryou','fyp','viral','trending','challenge','tiktok','explore','foryoupage','viral','trend']
        limit = 20
    elif platform == 'twitter':
        power_tags = ['trending','viral','twitter','news','breaking']
        limit = 8
    elif platform == 'linkedin':
        power_tags = ['professional','business','career','growth','networking','opportunity']
        limit = 5
    else:
        power_tags = ['instagood','instadaily','photooftheday','viral','trending','fyp','reels','explore']
        limit = 30

    hashtags.update(power_tags[:3])

    # Clean and format
    final = []
    for tag in hashtags:
        tag = re.sub(r'[^a-z0-9]', '', tag.lower())
        if tag and len(tag) >= 3:
            final.append('#' + tag)

    # Score: prefer longer/niche tags over short generic ones
    def score(tag):
        t = tag[1:]
        niche_bonus = 2 if any(t in v for v in NICHE_MAP.values()) else 0
        return len(t) + niche_bonus

    final = sorted(set(final), key=score, reverse=True)
    return final[:limit]

def categorize_hashtags(hashtags):
    """Split into groups for UI display"""
    niche, power, general = [], [], []
    power_set = {'instagood','instadaily','photooftheday','viral','trending','fyp','reels','explore'}
    for tag in hashtags:
        t = tag[1:]
        if t in power_set:
            power.append(tag)
        elif len(t) > 8:
            niche.append(tag)
        else:
            general.append(tag)
    return {
        'niche': niche[:12],
        'power': power[:6],
        'general': general[:12]
    }

# --------------- Routes ---------------

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/generate', methods=['POST'])
def generate():
    data = request.get_json()
    caption = data.get('caption', '').strip()
    platform = data.get('platform', 'instagram').lower()

    if not caption:
        return jsonify({'error': 'Please enter a caption'}), 400

    if len(caption) < 5:
        return jsonify({'error': 'Caption is too short'}), 400

    if platform not in ['instagram', 'tiktok', 'twitter', 'linkedin']:
        platform = 'instagram'

    hashtags = generate_hashtags(caption, platform)
    categorized = categorize_hashtags(hashtags)
    all_tags = ' '.join(hashtags)

    return jsonify({
        'hashtags': hashtags,
        'categorized': categorized,
        'all_text': all_tags,
        'count': len(hashtags),
        'platform': platform
    })

if __name__ == '__main__':
    app.run(debug=True)
